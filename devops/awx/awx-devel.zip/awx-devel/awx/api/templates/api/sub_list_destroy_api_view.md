{% include "api/sub_list_create_api_view.md" %}

# Delete all {{ model_verbose_name_plural }} of this {{ parent_model_verbose_name|title }}:

Make a DELETE request to this resource to delete all {{ model_verbose_name_plural }} show in the list.
The {{ parent_model_verbose_name|title }} will not be deleted by this request.
